import { useEffect, useState } from "react";
type Product = { id: string; name: string; description: string; price: number; stock: number; vendor: { storeName: string } };
const API = import.meta.env.VITE_API_URL || "http://localhost:4001";
export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    fetch(`${API}/api/products?search=${encodeURIComponent(search)}`)
      .then(r => { if (!r.ok) throw new Error("Could not load products"); return r.json(); })
      .then(setProducts).catch(() => setError("API is not connected yet. Start the backend and database."));
  }, [search]);
  return <main>
    <nav><div className="brand">Market<span>Hub</span></div><div className="nav-note">A marketplace for every seller</div><button onClick={() => alert("Customer/vendor authentication API is available. Connect your account UI next.")}>Sign in</button></nav>
    <section className="hero"><p className="eyebrow">ONE MARKETPLACE · MANY POSSIBILITIES</p><h1>Find your next<br/><em>great discovery.</em></h1><p>Shop independent vendors, discover products, and support small businesses.</p><div className="search"><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products..." /><span>⌕</span></div></section>
    <section className="catalog"><div className="section-head"><div><p className="eyebrow">CURATED FOR YOU</p><h2>Explore products</h2></div><span>{products.length} products</span></div>
      {error && <p className="error">{error}</p>}
      <div className="grid">{products.map(p => <article className="product" key={p.id}><div className="placeholder">✳</div><div className="product-info"><small>{p.vendor?.storeName || "Marketplace vendor"}</small><h3>{p.name}</h3><p>{p.description}</p><div className="price">₹{p.price.toLocaleString("en-IN")} <small>{p.stock} in stock</small></div></div></article>)}</div>
      {!products.length && !error && <p className="empty">No products yet. Add products using the vendor API after approving a vendor.</p>}
    </section><footer>MarketHub · FS-01 Full-Stack Marketplace · Internship portfolio project</footer>
  </main>;
}
