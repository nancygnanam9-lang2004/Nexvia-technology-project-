# FS-04 — Multi-Tenant SaaS Project Management Platform

A Jira-inspired project workspace foundation. Multiple organizations share the application while
workspace membership and tenant-scoped queries protect their data.

## Backend technology decision
Nexvia's project brief has a conflict: its technology list names Node.js/Express, while milestone 2
explicitly requires Django REST Framework and milestone 5 requires Celery. This starter uses
Node.js + Express to match the listed stack. Confirm with Nexvia whether the evaluator expects
Django REST Framework/Celery before treating this backend choice as final.

## Current implementation
- Express + TypeScript API
- PostgreSQL + Prisma schema
- User registration/login with password hashing and JWT
- Workspace creation; creator becomes OWNER
- Workspace membership checks on project, issue and audit-log endpoints
- Project and issue CRUD foundations
- Audit log entries for project/issue creation and issue updates
- React + TypeScript Kanban-style sample UI
- Docker Compose PostgreSQL service

## Run locally
1. Start PostgreSQL: `docker compose up -d`.
2. Backend: `cd backend`, copy `.env.example` to `.env`, then:
   `npm install`
   `npx prisma generate`
   `npx prisma db push`
   `npm run dev`
3. Frontend in a second terminal: `cd frontend`, then:
   `npm install`
   `npm run dev`
4. Open `http://localhost:5174`; API health check: `http://localhost:4002/health`.

## API starter
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/workspaces` — create workspace (creator is OWNER)
- `GET /api/workspaces` — list current user's workspaces
- `POST /api/workspaces/:workspaceId/projects`
- `GET /api/workspaces/:workspaceId/projects`
- `POST /api/projects/:projectId/issues`
- `PATCH /api/issues/:issueId`
- `GET /api/workspaces/:workspaceId/audit-log`

## Before final internship submission
Add workspace invitation/member management and enforce role-specific permissions, sprint CRUD,
comments, attachments, configurable workflows, true drag-and-drop backed by the API, webhooks,
background jobs/notifications, billing test integration and plan limits, automated tests, CI/CD,
deployment, API documentation, and architecture diagram.

## Tenant isolation note
The API checks that the authenticated user belongs to the workspace before returning or mutating
workspace resources. Keep every future tenant-owned query scoped through a verified workspace
membership. Add automated cross-tenant access tests before production use.
