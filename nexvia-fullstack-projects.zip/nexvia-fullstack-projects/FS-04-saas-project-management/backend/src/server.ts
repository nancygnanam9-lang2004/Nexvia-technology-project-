import "dotenv/config";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { PrismaClient, WorkspaceRole, IssueStatus, IssuePriority } from "@prisma/client";
import { z } from "zod";

const app = express();
const prisma = new PrismaClient();
const PORT = Number(process.env.PORT || 4002);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error("JWT_SECRET is required. Copy .env.example to .env and set it.");
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5174" }));
app.use(express.json());

type TokenData = { id: string; email: string };
type AuthRequest = express.Request & { user?: TokenData };
function auth(req: AuthRequest, res: express.Response, next: express.NextFunction) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "Authentication required" });
  try { req.user = jwt.verify(token, JWT_SECRET!) as TokenData; next(); }
  catch { return res.status(401).json({ error: "Invalid or expired token" }); }
}
async function membership(userId: string, workspaceId: string) {
  return prisma.membership.findUnique({ where: { userId_workspaceId: { userId, workspaceId } } });
}
app.get("/health", (_req, res) => res.json({ status: "ok", project: "FS-04 SaaS project management" }));

app.post("/api/auth/register", async (req, res) => {
  const parsed = z.object({ name: z.string().min(2), email: z.string().email(), password: z.string().min(8) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  try {
    const user = await prisma.user.create({ data: { ...parsed.data, passwordHash: await bcrypt.hash(parsed.data.password, 12) }, select: { id: true, name: true, email: true } });
    res.status(201).json(user);
  } catch { res.status(409).json({ error: "Email may already be registered." }); }
});
app.post("/api/auth/login", async (req, res) => {
  const parsed = z.object({ email: z.string().email(), password: z.string().min(1) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Valid email and password are required" });
  const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return res.status(401).json({ error: "Invalid credentials" });
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET!, { expiresIn: "8h" });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

app.post("/api/workspaces", auth, async (req: AuthRequest, res) => {
  const parsed = z.object({ name: z.string().min(2), slug: z.string().regex(/^[a-z0-9-]+$/).min(3) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  try {
    const workspace = await prisma.workspace.create({ data: { ...parsed.data, memberships: { create: { userId: req.user!.id, role: WorkspaceRole.OWNER } } } });
    res.status(201).json(workspace);
  } catch { res.status(409).json({ error: "Workspace slug is already in use." }); }
});
app.get("/api/workspaces", auth, async (req: AuthRequest, res) => {
  const memberships = await prisma.membership.findMany({ where: { userId: req.user!.id }, include: { workspace: true } });
  res.json(memberships.map(m => ({ ...m.workspace, role: m.role })));
});

app.post("/api/workspaces/:workspaceId/projects", auth, async (req: AuthRequest, res) => {
  const workspaceId = req.params.workspaceId;
  const member = await membership(req.user!.id, workspaceId);
  if (!member) return res.status(404).json({ error: "Workspace not found" });
  const parsed = z.object({ name: z.string().min(2), description: z.string().optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const project = await prisma.project.create({ data: { ...parsed.data, workspaceId } });
  await prisma.auditLog.create({ data: { workspaceId, actorId: req.user!.id, action: "PROJECT_CREATED", entityType: "Project", entityId: project.id } });
  res.status(201).json(project);
});
app.get("/api/workspaces/:workspaceId/projects", auth, async (req: AuthRequest, res) => {
  const workspaceId = req.params.workspaceId;
  if (!await membership(req.user!.id, workspaceId)) return res.status(404).json({ error: "Workspace not found" });
  res.json(await prisma.project.findMany({ where: { workspaceId }, include: { issues: true, sprints: true } }));
});
app.post("/api/projects/:projectId/issues", auth, async (req: AuthRequest, res) => {
  const project = await prisma.project.findUnique({ where: { id: req.params.projectId } });
  if (!project || !await membership(req.user!.id, project.workspaceId)) return res.status(404).json({ error: "Project not found" });
  const parsed = z.object({ title: z.string().min(2), description: z.string().optional(), status: z.nativeEnum(IssueStatus).optional(), priority: z.nativeEnum(IssuePriority).optional(), assignee: z.string().optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const issue = await prisma.issue.create({ data: { ...parsed.data, projectId: project.id } });
  await prisma.auditLog.create({ data: { workspaceId: project.workspaceId, actorId: req.user!.id, action: "ISSUE_CREATED", entityType: "Issue", entityId: issue.id } });
  res.status(201).json(issue);
});
app.patch("/api/issues/:issueId", auth, async (req: AuthRequest, res) => {
  const issue = await prisma.issue.findUnique({ where: { id: req.params.issueId }, include: { project: true } });
  if (!issue || !await membership(req.user!.id, issue.project.workspaceId)) return res.status(404).json({ error: "Issue not found" });
  const parsed = z.object({ title: z.string().min(2).optional(), description: z.string().optional(), status: z.nativeEnum(IssueStatus).optional(), priority: z.nativeEnum(IssuePriority).optional(), assignee: z.string().optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const updated = await prisma.issue.update({ where: { id: issue.id }, data: parsed.data });
  await prisma.auditLog.create({ data: { workspaceId: issue.project.workspaceId, actorId: req.user!.id, action: "ISSUE_UPDATED", entityType: "Issue", entityId: issue.id } });
  res.json(updated);
});
app.get("/api/workspaces/:workspaceId/audit-log", auth, async (req: AuthRequest, res) => {
  if (!await membership(req.user!.id, req.params.workspaceId)) return res.status(404).json({ error: "Workspace not found" });
  res.json(await prisma.auditLog.findMany({ where: { workspaceId: req.params.workspaceId }, orderBy: { createdAt: "desc" }, take: 100 }));
});

app.listen(PORT, () => console.log(`FS-04 API running at http://localhost:${PORT}`));
