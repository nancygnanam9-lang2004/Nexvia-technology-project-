# Nexvia Full-Stack Internship Projects

This repository contains two independent starter applications:

- `FS-01-ecommerce-marketplace`: multi-vendor marketplace API + React starter.
- `FS-04-saas-project-management`: tenant-isolated project management API + React starter.

## Important status
This is a runnable MVP foundation, not a claim that every Nexvia milestone is finished.
It includes working API foundations, database schemas, frontend starter screens, Docker PostgreSQL,
environment examples, and setup instructions. Payment processing, S3 uploads, Elasticsearch,
Redis, Celery, webhooks, PDF invoices, and production deployment must be configured and tested
before final submission.

## Requirements
- Node.js 20+
- npm
- Docker Desktop (or a local PostgreSQL installation)
- Git

Each project has its own README. Start with the project folders.
